import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLmxvY2tqYXc=')

name = b.b64decode('TG9jayBKYXc=')

host = b.b64decode('aHR0cDovL3RoZXBrLmNv')

port = b.b64decode('MjA5NQ==')