import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLnJvY2tldHBvd2Vy')

name = b.b64decode('Um9ja2V0IFBvd2Vy')

host = b.b64decode('aHR0cDovL3N0cmVhbS10d28uZG9jMTIzLm5s')

port = b.b64decode('ODAwMA==')