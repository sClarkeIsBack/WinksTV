import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLnN1aWNpZGVub3Rl')

name = b.b64decode('U3VpY2lkZSBOb3Rl')

host = b.b64decode('aHR0cDovL3Nydi5nYWxheHlpcHR2Lm5ldA==')

port = b.b64decode('ODA4MA==')